package com.example.flyingbirdactivityice1

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {

    private lateinit var imageView4: ImageView

    private lateinit var startButton: Button


    private lateinit var tower3: ImageView

    private lateinit var tower1: ImageView

    private lateinit var tower2: ImageView

    private lateinit var imageView7: ImageView


    private lateinit var imageView8: ImageView


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startButton = findViewById(R.id.startbtn)
        tower3 = findViewById(R.id.tower3)
        tower1 = findViewById(R.id.tower1)
        tower2 = findViewById(R.id.tower2)
        imageView7 = findViewById(R.id.imageView7)
        imageView8 = findViewById(R.id.imageView8)
        imageView4 = findViewById(R.id.imageView4) // Initialize imageView4

        startButton.setOnClickListener {
            val screenWidth = getScreenWidth()
            startAnimation(tower3, screenWidth)
            startAnimation(tower1, screenWidth)
            startAnimation(tower2, screenWidth)
            startAnimation(imageView7, screenWidth)
            startAnimation(imageView8, screenWidth)

            // Animate imageView4 to move left and adjust vertical position
            startVerticalAnimation(imageView4)
            startHorizontalAnimation(imageView4, screenWidth)
        }
    }

    private fun startAnimation(view: View, screenWidth: Int) {
        val animator = ObjectAnimator.ofFloat(view, "translationX", 0f, screenWidth.toFloat())
        animator.duration = 5000 // 5 seconds duration
        animator.repeatCount = ObjectAnimator.INFINITE // Repeat infinitely
        animator.repeatMode = ObjectAnimator.RESTART // Restart animation after reaching end
        animator.start()
    }

    private fun startVerticalAnimation(view: View) {
        val animator =
            ObjectAnimator.ofFloat(view, "translationY", 0f, 200f) // Move vertically 200 pixels
        animator.duration = 5000 // 5 seconds duration
        animator.repeatCount = ObjectAnimator.INFINITE // Repeat infinitely
        animator.repeatMode = ObjectAnimator.REVERSE // Move up and down
        animator.start()
    }

    private fun startHorizontalAnimation(view: View, screenWidth: Int) {
        val animator = ObjectAnimator.ofFloat(view, "translationX", 0f, -screenWidth.toFloat())
        animator.duration = 5000 // 5 seconds duration
        animator.repeatCount = ObjectAnimator.INFINITE // Repeat infinitely
        animator.repeatMode = ObjectAnimator.RESTART // Restart animation after reaching end
        animator.start()
    }

    private fun getScreenWidth(): Int {
        val displayMetrics = resources.displayMetrics
        return displayMetrics.widthPixels
    }
}